#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --algorithm pufferfish2bmb --pool bmb.ffmpool.com:4444 --wallet 0019DF9EB6DD048E8AFE9FE11F9232F65F1D7B5D214F66E721
