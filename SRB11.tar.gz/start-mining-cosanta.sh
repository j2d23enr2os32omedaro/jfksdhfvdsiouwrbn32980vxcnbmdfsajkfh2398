#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm cosa --pool stratum-eu.rplant.xyz:7086 --wallet CcDYU1yspx79XmtrWK3kotR7nh2uzzaiiE --password x
