#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm minotaurx --pool stratum-eu.rplant.xyz:7068 --wallet RPgN8g5K2TpsVDHiQgt9t1wtbZS3yde9e1
